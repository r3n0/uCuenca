<?php
/**
 * FUnciones generals
 *
 * Este es el documento de funciones
 *
 * @category   Components
 * @package    WordPress
 * @subpackage Theme_Name_Here
 * @author     Your Name <yourname@example.com>
 * @license    https://www.gnu.org/licenses/gpl-3.0.txt GNU/GPLv3
 * @link       https://yoursite.com
 */

require_once 'lib/helpers.php';
require_once 'lib/enqueue-assets.php';
